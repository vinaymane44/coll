#include <iostream>
using namespace std;

void print(){
	cout<<"Hello world"<<endl;
}

int main(){
	print();
	return 0;
}